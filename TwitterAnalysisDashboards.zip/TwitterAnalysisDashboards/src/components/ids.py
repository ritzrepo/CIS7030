BAR_CHART = "bar-chart"
# PIE_CHART = "pie-chart"
LINE_CHART  = "line-chart"
LINE_CHART_KEYWORD   = "line-chart-keyword"
SCATTER_CHART  = "scatter-chart"
SCATTER_CHART_LIKE_RETWEET  = "scatter_chart_like_retweet"
WORD_CLOUD ="word-cloud"
WORD_CLOUD_IMG="word-cloud-img"
WORD_CLOUD_SENTIMENT="word-cloud-sentiment"
# CHANNEL_BAR_CHART = "channel-bar-chart"
# VIDEO_BAR_CHART  = "video-bar-chart"
# VIDEO_SCATTER_CHART  = "video-scatter-chart"
TWEETER_TIME_CHART  = "tweeter-time-chart"
# INSTAGRAM_BAR_CHART  = "instagram-bar-chart"
# CH_COMMENT_VIDEO_TIME_CHART  = "ch-comment-video-time-chart"
# CH_COMMENT_VIDEO_TIME_TABLE  = "ch-comment-video-table"

SELECT_ALL_CHANNELS_BUTTON = "select-all-channels-button"
CHANNEL_DROPDOWN = "channel-dropdown"

SELECT_ALL_MONTHS_BUTTON = "select-all-months-button"
MONTH_DROPDOWN = "month-dropdown"

SELECT_ALL_YEARS_BUTTON = "select-all-years-button"
YEAR_DROPDOWN = "year-dropdown"

SELECT_ALL_DATES_BUTTON = "select-all-dates-button"
DATE_DROPDOWN = "date-dropdown"


# KEYWORD_INPUT = "keyword-input"
KEYWORD_OUTPUT = "keyword-output"
# SELECT_ALL_VIDEOS_BUTTON = "select-all-video-button" 
# VIDEO_DROPDOWN = "video-dropdown"